Excel files have trials and active time.
Load each, find the mean active time by percent
store it in a new excel file
plot the data by group
save the figure

