The data in this folder is downloaded from:
https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE61326


It is cropped to include only the datatable without header/metadata.

Stored as a tab-separated file (tsv) can be loaded into excel


